/*
 *  AstroWax Panel 4.0
 *  (c) 2026 ITZ_YTANSH
 */

const express = require("express");
const session = require("express-session");
const passport = require("passport");
const bodyParser = require("body-parser");
const fs = require("node:fs");
const config = require("./config.json");
const ascii = fs.readFileSync("./handlers/ascii.txt", "utf8");
const app = express();
const path = require("path");
const chalk = require("chalk");
const expressWs = require("express-ws")(app);
const { db } = require("./handlers/db.js");
const translationMiddleware = require("./handlers/translation");
const cookieParser = require("cookie-parser");
const rateLimit = require("express-rate-limit");
const theme = require("./storage/theme.json");
const analytics = require("./utils/analytics.js");
const crypto = require("crypto");
const sqlite3 = require('sqlite3').verbose();
const SqliteStore = require('connect-sqlite3')(session);

const { loadPlugins } = require("./plugins/loadPls.js");
let plugins = loadPlugins(path.join(__dirname, "./plugins"));
plugins = Object.values(plugins).map((plugin) => plugin.config);

const { init } = require("./handlers/init.js");
const log = new (require("cat-loggr"))();

// Session configuration
app.use(
  session({
    store: new SqliteStore({
      db: 'sessions.db',
      dir: './storage',
      table: 'sessions',
      cleanUpInterval: 9000000,
    }),
    secret: config.session_secret || "0\u0013ãì'>tÚ`iî«9Ëÿ",
    resave: true,
    saveUninitialized: true,
    cookie: {
      secure: config.mode === "production",
      maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
  })
);

// Middleware setup
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(cookieParser());
app.use(analytics);
app.use(translationMiddleware);
app.use(passport.initialize());
app.use(passport.session());

// Rate limiting
const postRateLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 6,
  message: "Too many requests, please try again later"
});

app.use((req, res, next) => {
  if (req.method === "POST") {
    postRateLimiter(req, res, next);
  } else {
    next();
  }
});

// Random string generator
function generateRandomString(length) {
  return crypto
    .randomBytes(length)
    .toString('hex')
    .slice(0, length);
}

// Update config with random values
async function updateConfig() {
  const configPath = "./config.json";
  try {
    let configData = fs.readFileSync(configPath, "utf8");
    let config = JSON.parse(configData);
    replaceRandomValues(config);
    fs.writeFileSync(configPath, JSON.stringify(config, null, 2), "utf8");
  } catch (error) {
    log.error("Error updating config:", error);
  }
}

function replaceRandomValues(obj) {
  for (const key in obj) {
    if (typeof obj[key] === "object" && obj[key] !== null) {
      replaceRandomValues(obj[key]);
    } else if (obj[key] === "Random") {
      obj[key] = generateRandomString(16);
    }
  }
}

updateConfig();

function getLanguages() {
  return fs.readdirSync(__dirname + "/lang").map((file) => file.split(".")[0]);
}

app.get("/setLanguage", async (req, res) => {
  const lang = req.query.lang;
  if (lang && getLanguages().includes(lang)) {
    res.cookie("lang", lang, {
      maxAge: 90000000,
      httpOnly: true,
      sameSite: "strict",
    });
    req.user.lang = lang;
    res.json({ success: true });
  } else {
    res.json({ success: false });
  }
});

// Global middleware for template variables
app.use(async (req, res, next) => {
  try {
    const settings = await db.get("settings");
    res.locals.showSnowfall = true;
    res.locals.languages = getLanguages();
    res.locals.ogTitle = config.ogTitle || "AstroWax Panel";
    res.locals.ogDescription = config.ogDescription || "Manage your game servers with AstroWax Panel";
    res.locals.footer = settings?.footer || "© 2026 AstroWax Panel";
    res.locals.theme = theme;
    res.locals.name = settings?.name || "AstroWax Panel";
    res.locals.logo = config.logo ? "/assets/logo.png" : null;
    res.locals.plugins = plugins;
    next();
  } catch (error) {
    log.error("Error fetching settings:", error);
    res.locals.showSnowfall = true;
    res.locals.name = "AstroWax Panel";
    next();
  }
});

// Cache headers for production
if (config.mode === "production") {
  app.use((req, res, next) => {
    res.setHeader("Cache-Control", "no-store");
    res.setHeader("Pragma", "no-cache");
    res.setHeader("Expires", "5");
    next();
  });

  app.use("/assets", (req, res, next) => {
    res.setHeader("Cache-Control", "public, max-age=31536000");
    next();
  });
}

app.set("view engine", "ejs");
app.use(express.static("public"));

// Load routes
const routesDir = path.join(__dirname, "routes");
function loadRoutes(directory) {
  fs.readdirSync(directory).forEach((file) => {
    const fullPath = path.join(directory, file);
    const stat = fs.statSync(fullPath);

    if (stat.isDirectory()) {
      loadRoutes(fullPath);
    } else if (stat.isFile() && path.extname(file) === ".js") {
      const route = require(fullPath);
      expressWs.applyTo(route);
      app.use("/", route);
    }
  });
}
loadRoutes(routesDir);

// Plugin routes
const pluginRoutes = require("./plugins/pluginmanager.js");
app.use("/", pluginRoutes);
const pluginDir = path.join(__dirname, "plugins");
const PluginViewsDir = fs
  .readdirSync(pluginDir)
  .map((addonName) => path.join(pluginDir, addonName, "views"));
app.set("views", [path.join(__dirname, "views"), ...PluginViewsDir]);

// Initialize and start server
init();
console.log(chalk.gray(ascii) + chalk.white(`AstroWax Panel v${config.version}\n`));
app.listen(config.port, () => {
  log.info(`AstroWax Panel is running on http://localhost:${config.port}`);
  console.log(`\n${chalk.bgBlue(' INFO ')} Panel ready at: ${chalk.blue(`http://localhost:${config.port}`)}`);
});

// 404 handler
app.get("*", async function (req, res) {
  res.render("errors/404", {
    req,
    name: (await db.get("name")) || "AstroWax Panel",
  });
});