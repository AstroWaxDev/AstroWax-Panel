const config = require('../config.json');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');

// Create storage directory if it doesn't exist
const storageDir = path.join(__dirname, '../storage');
if (!fs.existsSync(storageDir)) {
  fs.mkdirSync(storageDir, { recursive: true });
}

// Database connection
const dbPath = path.join(storageDir, 'skyport.db');
const db = new sqlite3.Database(dbPath);

// Create tables with error handling
function initializeDatabase() {
  return new Promise((resolve, reject) => {
    db.serialize(() => {
      const tables = [
        `CREATE TABLE IF NOT EXISTS settings (
          key TEXT PRIMARY KEY,
          value TEXT
        )`,

        `CREATE TABLE IF NOT EXISTS users (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          username TEXT UNIQUE NOT NULL,
          email TEXT UNIQUE NOT NULL,
          password TEXT NOT NULL,
          admin BOOLEAN DEFAULT FALSE,
          verified BOOLEAN DEFAULT FALSE,
          verificationToken TEXT,
          resetToken TEXT,
          resetTokenExpires INTEGER,
          createdAt INTEGER DEFAULT (strftime('%s', 'now')),
          updatedAt INTEGER DEFAULT (strftime('%s', 'now')),
          lang TEXT DEFAULT 'en',
          twoFactorSecret TEXT,
          twoFactorEnabled BOOLEAN DEFAULT FALSE
        )`,

        `CREATE TABLE IF NOT EXISTS sessions (
          sid TEXT PRIMARY KEY,
          sess TEXT NOT NULL,
          expire INTEGER NOT NULL
        )`,

        `CREATE TABLE IF NOT EXISTS instances (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          instanceId TEXT UNIQUE NOT NULL,
          name TEXT NOT NULL,
          nodeId INTEGER NOT NULL,
          userId INTEGER NOT NULL,
          image TEXT NOT NULL,
          memory INTEGER NOT NULL,
          disk INTEGER NOT NULL,
          cpu INTEGER NOT NULL,
          ports TEXT NOT NULL,
          primaryPort INTEGER NOT NULL,
          status TEXT DEFAULT 'offline',
          suspended BOOLEAN DEFAULT FALSE,
          createdAt INTEGER DEFAULT (strftime('%s', 'now')),
          updatedAt INTEGER DEFAULT (strftime('%s', 'now')),
          configFilePath TEXT,
          configFileContent TEXT,
          variables TEXT
        )`,

        `CREATE TABLE IF NOT EXISTS nodes (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT UNIQUE NOT NULL,
          address TEXT NOT NULL,
          port INTEGER NOT NULL,
          apiKey TEXT NOT NULL,
          status TEXT DEFAULT 'offline',
          createdAt INTEGER DEFAULT (strftime('%s', 'now')),
          updatedAt INTEGER DEFAULT (strftime('%s', 'now'))
        )`,

        `CREATE TABLE IF NOT EXISTS audit_logs (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          userId INTEGER,
          action TEXT NOT NULL,
          targetType TEXT,
          targetId TEXT,
          oldValue TEXT,
          newValue TEXT,
          ipAddress TEXT,
          userAgent TEXT,
          createdAt INTEGER DEFAULT (strftime('%s', 'now'))
        )`,

        `CREATE TABLE IF NOT EXISTS images (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT UNIQUE NOT NULL,
          image TEXT NOT NULL,
          configFilePath TEXT,
          configFileContent TEXT,
          variables TEXT,
          createdAt INTEGER DEFAULT (strftime('%s', 'now')),
          updatedAt INTEGER DEFAULT (strftime('%s', 'now'))
        )`,

        `CREATE TABLE IF NOT EXISTS api_keys (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          userId INTEGER NOT NULL,
          key TEXT UNIQUE NOT NULL,
          name TEXT,
          permissions TEXT,
          lastUsed INTEGER,
          createdAt INTEGER DEFAULT (strftime('%s', 'now')),
          FOREIGN KEY (userId) REFERENCES users(id)
        )`
      ];

      tables.forEach(sql => {
        db.run(sql, (err) => {
          if (err) console.error(`Error creating table: ${err.message}`);
        });
      });

      resolve();
    });
  });
}

// Database wrapper with promise-based methods
const database = {
  get: (key) => new Promise((resolve, reject) => {
    db.get('SELECT value FROM settings WHERE key = ?', [key], (err, row) => {
      if (err) return reject(err);
      resolve(row ? JSON.parse(row.value) : null);
    });
  }),

  set: (key, value) => new Promise((resolve, reject) => {
    const valueStr = JSON.stringify(value);
    db.run('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', [key, valueStr], (err) => {
      if (err) return reject(err);
      resolve();
    });
  }),

  query: (sql, params = []) => new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) return reject(err);
      resolve(rows);
    });
  }),

  run: (sql, params = []) => new Promise((resolve, reject) => {
    db.run(sql, params, function(err) {
      if (err) return reject(err);
      resolve(this);
    });
  }),

  close: () => new Promise((resolve, reject) => {
    db.close((err) => {
      if (err) return reject(err);
      resolve();
    });
  }),

  initDefaultSettings: async () => {
    const defaults = {
      name: "AstroWax Panel",
      logo: "/assets/logo.png",
      footer: "© 2026 AstroWax Panel",
      maintenance: false,
      registrations: true,
      theme: "dark",
      defaultLanguage: "en"
    };

    for (const [key, value] of Object.entries(defaults)) {
      try {
        const existing = await database.get(key);
        if (!existing) {
          await database.set(key, value);
        }
      } catch (err) {
        console.error(`Error setting default ${key}:`, err);
      }
    }
  }
};

// Initialize everything
initializeDatabase()
  .then(() => database.initDefaultSettings())
  .catch(err => console.error("Database initialization failed:", err));

module.exports = { db: database };