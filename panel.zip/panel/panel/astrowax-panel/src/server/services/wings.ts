import axios from "axios";
import { GameServerRuntimeProvider } from "./runtimeProvider.js";
import { readJSON } from "./db.js";
import { getJavaVersionForMinecraft } from "../../utils/minecraftJava.js";

async function getWingsNode(nodeId: string) {
  const nodes = (await readJSON("wings_nodes.json")) || [];
  return nodes.find((n: any) => n.id === nodeId);
}

function getWingsClient(node: any) {
  let url = node.apiUrl;

  if (!url) {
    const protocol = node.ssl ? "https" : "http";
    url = `${protocol}://${node.hostname}:${node.apiPort || 8080}`;
  }

  return axios.create({
    baseURL: url,
    headers: {
      Authorization: `Bearer ${node.token}`,
      Accept: "application/json",
      "Content-Type": "application/json",
    },
  });
}

// Fix common invalid Node.js Docker image names
function normalizeDockerImage(image?: string): string {
  if (!image) return "";

  const normalized = image.trim();

  if (
    normalized === "node:26x-alpine" ||
    normalized === "node:26.x-alpine"
  ) {
    return "node:26-alpine";
  }

  return normalized;
}

// Paper 1.21 + old Paper builds can crash with Java 25's
// bundled spark/async-profiler. Keep Java 21 as the safe fallback.
function getSafeJavaVersion(
  minecraftVersion: string,
  serverType?: string
): string {
  const version = minecraftVersion.toLowerCase().trim();

  // Minecraft/Paper 1.21.x
  if (
    serverType?.toLowerCase() === "paper" &&
    /^1\.21(\.|$)/.test(version)
  ) {
    return "21";
  }

  // Minecraft 1.20.5+ requires Java 21.
  if (/^1\.(20\.[5-9]|2[1-9])(\.|$)/.test(version)) {
    return "21";
  }

  return getJavaVersionForMinecraft(minecraftVersion, serverType);
}

export class WingsRuntimeProvider
  implements GameServerRuntimeProvider
{
  async getNodeHealth(nodeId: string) {
    const node = await getWingsNode(nodeId);

    if (!node) {
      throw new Error("Node not found");
    }

    const client = getWingsClient(node);

    try {
      const res = await client.get("/api/system");
      return res.data;
    } catch (err: any) {
      throw new Error(
        `Wings Health Check Failed: ${err.message}`
      );
    }
  }

  async getNodeAllocations(nodeId: string) {
    return [];
  }

  async createServer(server: any): Promise<void> {
    const node = await getWingsNode(server.nodeId);

    if (!node) {
      throw new Error("Node not found");
    }

    const client = getWingsClient(node);

    const minecraftVersion = server.version || "1.21";

    /*
     * Priority:
     * 1. Explicit server.javaVersion
     * 2. Safe automatic Java version
     */
    const effectiveJava =
      server.javaVersion ||
      getSafeJavaVersion(
        minecraftVersion,
        server.type
      );

    const javaVersion = `java_${effectiveJava}`;

    const requestedImage = normalizeDockerImage(
      server.dockerImage
    );

    const image =
      requestedImage ||
      `ghcr.io/pterodactyl/yolks:${javaVersion}`;

    console.log(
      `[Wings] Creating server ${server.id}`
    );

    console.log(
      `[Wings] Minecraft: ${minecraftVersion}`
    );

    console.log(
      `[Wings] Java: ${effectiveJava}`
    );

    console.log(
      `[Wings] Docker image: ${image}`
    );

    const payload = {
      uuid: server.id,

      meta: {
        name: server.name || "Minecraft Server",
        description: "A Minecraft Server",
      },

      suspended: false,

      environment: {
        SERVER_JARFILE:
          server.jarFile || "server.jar",
      },

      invocation:
        server.startupCommand ||
        "java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}}",

      skip_egg_scripts: true,

      build: {
        memory: server.memory || 1024,
        swap: 0,
        io: 500,
        cpu: server.cpu || 100,
        disk: server.disk || 10240,
        threads: null,
      },

      container: {
        image,
      },

      allocations: {
        default: {
          ip: server.ip || "0.0.0.0",
          port: server.port || 25565,
        },

        mappings: {
          [server.ip || "0.0.0.0"]: [
            server.port || 25565,
          ],
        },
      },
    };

    await client.post(
      "/api/servers",
      payload
    );
  }

  async deleteServer(
    serverId: string
  ): Promise<void> {
    const servers =
      (await readJSON("servers.json")) || [];

    const server = servers.find(
      (s: any) => s.id === serverId
    );

    if (!server?.nodeId) {
      return;
    }

    const node = await getWingsNode(
      server.nodeId
    );

    if (!node) {
      return;
    }

    const client = getWingsClient(node);

    await client.delete(
      `/api/servers/${serverId}`
    );
  }

  async startServer(
    serverId: string
  ): Promise<void> {
    await this.sendPowerAction(
      serverId,
      "start"
    );
  }

  async stopServer(
    serverId: string
  ): Promise<void> {
    await this.sendPowerAction(
      serverId,
      "stop"
    );
  }

  async restartServer(
    serverId: string
  ): Promise<void> {
    await this.sendPowerAction(
      serverId,
      "restart"
    );
  }

  async killServer(
    serverId: string
  ): Promise<void> {
    await this.sendPowerAction(
      serverId,
      "kill"
    );
  }

  async reinstallServer(
    serverId: string
  ): Promise<void> {
    // Wings does not directly support reinstall
    // through a normal power action.
    // Usually the panel recreates/rebuilds the server.
  }

  private async sendPowerAction(
    serverId: string,
    action: string
  ) {
    const servers =
      (await readJSON("servers.json")) || [];

    const server = servers.find(
      (s: any) => s.id === serverId
    );

    if (!server?.nodeId) {
      throw new Error("Server not found");
    }

    const node = await getWingsNode(
      server.nodeId
    );

    if (!node) {
      throw new Error("Node not found");
    }

    const client = getWingsClient(node);

    await client.post(
      `/api/servers/${serverId}/power`,
      { action }
    );
  }

  async getServerStatus(
    serverId: string
  ): Promise<any> {
    const servers =
      (await readJSON("servers.json")) || [];

    const server = servers.find(
      (s: any) => s.id === serverId
    );

    if (!server?.nodeId) {
      return {
        State: {
          Running: false,
          Status: "exited",
        },
      };
    }

    const node = await getWingsNode(
      server.nodeId
    );

    if (!node) {
      return {
        State: {
          Running: false,
          Status: "exited",
        },
      };
    }

    try {
      const client = getWingsClient(node);

      const res = await client.get(
        `/api/servers/${serverId}`
      );

      return {
        State: {
          Running:
            res.data.state !== "offline",
          Status: res.data.state,
        },
      };
    } catch {
      return {
        State: {
          Running: false,
          Status: "exited",
        },
      };
    }
  }

  async getServerStats(
    serverId: string
  ): Promise<any> {
    // TODO: Implement Wings websocket/stats endpoint.
    return {
      cpu: 0,
      ram: 0,
      disk: 0,
    };
  }

  async getConsoleLogs(
    serverId: string
  ): Promise<string> {
    return "[Wings] Logs not implemented via HTTP, usually WS.";
  }

  async subscribeToConsole(
    serverId: string,
    onData: (data: string) => void
  ): Promise<() => void> {
    // TODO: Implement Wings websocket connection.
    return () => {};
  }

  async sendConsoleCommand(
    serverId: string,
    command: string
  ): Promise<void> {
    const servers =
      (await readJSON("servers.json")) || [];

    const server = servers.find(
      (s: any) => s.id === serverId
    );

    if (!server?.nodeId) {
      return;
    }

    const node = await getWingsNode(
      server.nodeId
    );

    if (!node) {
      return;
    }

    const client = getWingsClient(node);

    await client.post(
      `/api/servers/${serverId}/commands`,
      { command }
    );
  }

  async listFiles(
    serverId: string,
    dir: string
  ): Promise<any[]> {
    return [];
  }

  async uploadFile(
    serverId: string,
    dir: string,
    file: any
  ): Promise<void> {}

  async downloadFile(
    serverId: string,
    filePath: string
  ): Promise<any> {
    return null;
  }

  async extractArchive(
    serverId: string,
    archivePath: string,
    destDir: string
  ): Promise<void> {}

  async createBackup(
    serverId: string
  ): Promise<any> {
    return {};
  }

  async restoreBackup(
    serverId: string,
    backupId: string
  ): Promise<void> {}

  async importWorld(
    serverId: string,
    worldData: any
  ): Promise<void> {}

  async exportWorld(
    serverId: string
  ): Promise<any> {
    return null;
  }
}