import express, { Request, Response } from "express";
import axios from "axios";
import { readJSON, writeJSON } from "../services/db.js";
import { requireAuth } from "../middleware/auth.js";

const router = express.Router();

// ═══════════════════════════════════════════
// VERSION CACHE (5 min TTL)
// ═══════════════════════════════════════════
const versionCache: Record<string, { data: string[]; expires: number }> = {};
const VERSION_CACHE_TTL = 5 * 60 * 1000;

async function cachedVersions(
  key: string,
  fn: () => Promise<string[]>
): Promise<string[]> {
  const now = Date.now();
  if (versionCache[key] && versionCache[key].expires > now) {
    return versionCache[key].data;
  }
  try {
    const data = await fn();
    versionCache[key] = { data, expires: now + VERSION_CACHE_TTL };
    return data;
  } catch (err) {
    // Fall back to stale cache if refresh fails
    if (versionCache[key]) return versionCache[key].data;
    throw err;
  }
}

// ═══════════════════════════════════════════
// VERSION FETCHERS
// ═══════════════════════════════════════════
async function fetchPaperVersions(): Promise<string[]> {
  const { data } = await axios.get(
    "https://api.papermc.io/v2/projects/paper",
    { timeout: 8000 }
  );
  const versions: string[] = Array.isArray(data?.versions) ? data.versions : [];
  return versions.slice().reverse(); // newest first
}

async function fetchSpigotVersions(): Promise<string[]> {
  return [
    "1.21.4","1.21.3","1.21.1","1.21",
    "1.20.6","1.20.4","1.20.2","1.20.1","1.20",
    "1.19.4","1.19.3","1.19.2","1.19",
    "1.18.2","1.18.1","1.18",
    "1.17.1","1.17",
    "1.16.5","1.16.4","1.16.3","1.16.1","1.16",
    "1.15.2","1.15.1","1.15",
    "1.14.4","1.14.3","1.14.2","1.14",
    "1.13.2","1.13.1","1.13",
    "1.12.2","1.12.1","1.12",
    "1.11.2","1.10.2","1.9.4","1.8.9","1.7.10",
  ];
}

async function fetchFabricVersions(): Promise<string[]> {
  const { data } = await axios.get(
    "https://meta.fabricmc.net/v2/versions/game",
    { timeout: 8000 }
  );
  const list = Array.isArray(data) ? data : [];
  return list
    .filter((v: any) => v && v.stable)
    .map((v: any) => String(v.version))
    .slice(0, 60);
}

async function fetchForgeVersions(): Promise<string[]> {
  const { data } = await axios.get(
    "https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json",
    { timeout: 8000 }
  );
  const promos = data?.promos || {};
  const versions = new Set<string>();
  Object.keys(promos).forEach((k) => {
    const mc = k.replace(/-latest$|-recommended$/, "");
    if (mc) versions.add(mc);
  });
  return Array.from(versions).sort().reverse();
}

async function fetchBungeeVersions(): Promise<string[]> {
  return [
    "1.21","1.20","1.19","1.18","1.17","1.16","1.15",
    "1.14","1.13","1.12","1.11","1.10","1.9","1.8",
  ];
}

async function fetchVelocityVersions(): Promise<string[]> {
  return ["3.3.0", "3.2.0", "3.1.0", "3.0.0"];
}

async function fetchNodeVersions(): Promise<string[]> {
  const { data } = await axios.get("https://nodejs.org/dist/index.json", {
    timeout: 8000,
  });
  const list = Array.isArray(data) ? data : [];
  const majors = new Set<string>();
  list.forEach((r: any) => {
    const major = String(r.version || "").replace(/^v/, "").split(".")[0];
    if (major) majors.add(major);
  });
  return Array.from(majors)
    .sort((a, b) => Number(b) - Number(a))
    .slice(0, 8)
    .map((m) => `${m}.x`);
}

async function fetchPythonVersions(): Promise<string[]> {
  return ["3.13", "3.12", "3.11", "3.10", "3.9", "3.8"];
}

// ═══════════════════════════════════════════
// GET /api/system/versions?type=paper
// ═══════════════════════════════════════════
router.get("/versions", async (req: Request, res: Response) => {
  const type = String(req.query.type || "paper").toLowerCase();

  try {
    let versions: string[] = [];

    switch (type) {
      case "paper":
        versions = await cachedVersions("paper", fetchPaperVersions);
        break;
      case "spigot":
        versions = await cachedVersions("spigot", fetchSpigotVersions);
        break;
      case "fabric":
        versions = await cachedVersions("fabric", fetchFabricVersions);
        break;
      case "forge":
        versions = await cachedVersions("forge", fetchForgeVersions);
        break;
      case "bungeecord":
        versions = await cachedVersions("bungee", fetchBungeeVersions);
        break;
      case "velocity":
        versions = await cachedVersions("velocity", fetchVelocityVersions);
        break;
      case "nodejs":
      case "node":
        versions = await cachedVersions("node", fetchNodeVersions);
        break;
      case "python":
      case "python3":
        versions = await cachedVersions("python", fetchPythonVersions);
        break;
      default:
        versions = ["latest"];
    }

    if (!Array.isArray(versions) || versions.length === 0) {
      versions = ["latest"];
    }

    res.json({ versions, type });
  } catch (err: any) {
    console.error(`[versions] ${type} failed:`, err.message);
    // Return empty so frontend uses its own fallback
    res.json({ versions: [], type, error: err.message });
  }
});

// ═══════════════════════════════════════════
// GET /api/system/settings
// ═══════════════════════════════════════════
router.get("/settings", async (req: Request, res: Response) => {
  try {
    const settings = (await readJSON("settings.json")) || {};

    res.json({
      version: "1.80",
      panelName: settings.panelName || "AstroWax Panel",
      panelLogo: settings.panelLogo || "",
      panelBackgroundImage: settings.panelBackgroundImage || "",
      panelBackgroundBlur:
        settings.panelBackgroundBlur !== undefined
          ? settings.panelBackgroundBlur
          : 10,
      enablePlayit:
        settings.enablePlayit !== undefined ? settings.enablePlayit : false,
      enableTutorial:
        settings.enableTutorial !== undefined ? settings.enableTutorial : true,
      enableLoginAnimation:
        settings.enableLoginAnimation !== undefined
          ? settings.enableLoginAnimation
          : true,
      enableRegistration:
        settings.enableRegistration !== undefined
          ? settings.enableRegistration
          : true,
      theme: settings.theme || "purple",
      enableGoogleLogin:
        settings.enableGoogleLogin !== undefined
          ? settings.enableGoogleLogin
          : false,
      firebaseApiKey: settings.firebaseApiKey || "",
      firebaseAuthDomain: settings.firebaseAuthDomain || "",
      firebaseProjectId: settings.firebaseProjectId || "",
      firebaseStorageBucket: settings.firebaseStorageBucket || "",
      firebaseMessagingSenderId: settings.firebaseMessagingSenderId || "",
      firebaseAppId: settings.firebaseAppId || "",
      defaultRuntime:
        settings.defaultRuntime || process.env.DEFAULT_RUNTIME || "docker",
      isDevPanel:
        (process.env.PANEL_TYPE === "dev" || process.env.PORT === "3000") &&
        !process.env.FORCE_MAIN_PANEL,
      panelPort: process.env.PORT || "3004",
    });
  } catch (err) {
    console.error("GET settings error:", err);
    res.status(500).json({ error: "Failed to load settings" });
  }
});

// ═══════════════════════════════════════════
// PUT /api/system/settings — UPDATE
// ═══════════════════════════════════════════
router.put("/settings", requireAuth, async (req: Request, res: Response) => {
  try {
    const existing = (await readJSON("settings.json")) || {};

    // ✅ ALLOWED FIELDS — includes wallpaper
    const allowedFields = [
      "panelName",
      "panelLogo",
      "panelBackgroundImage",       // ← WALLPAPER URL
      "panelBackgroundBlur",        // ← BLUR AMOUNT
      "enablePlayit",
      "enableTutorial",
      "enableLoginAnimation",
      "enableRegistration",
      "theme",                      // ← THEME ID
      "enableGoogleLogin",
      "firebaseApiKey",
      "firebaseAuthDomain",
      "firebaseProjectId",
      "firebaseStorageBucket",
      "firebaseMessagingSenderId",
      "firebaseAppId",
      "defaultRuntime",
    ];

    const updates: any = {};
    for (const key of allowedFields) {
      if (req.body[key] !== undefined) {
        updates[key] = req.body[key];
      }
    }

    const merged = { ...existing, ...updates };
    await writeJSON("settings.json", merged);

    console.log("✅ Settings updated:", Object.keys(updates).join(", "));

    res.json({ success: true, settings: merged });
  } catch (err: any) {
    console.error("PUT settings error:", err);
    res.status(500).json({ error: "Failed to update settings" });
  }
});

// ═══════════════════════════════════════════
// GET /api/system/users — List all users
// ═══════════════════════════════════════════
router.get("/users", requireAuth, async (req: Request, res: Response) => {
  try {
    const users = (await readJSON("users.json")) || [];
    res.json(
      users.map((u: any) => ({
        id: u.id,
        username: u.username,
        role: u.role,
        isGoogleUser: !!u.googleId,
        createdAt: u.createdAt || null,
        lastLogin: u.lastLogin || null,
      }))
    );
  } catch (err) {
    console.error("GET users error:", err);
    res.status(500).json({ error: "Failed to load users" });
  }
});

// ═══════════════════════════════════════════
// POST /api/system/users — Create user
// ═══════════════════════════════════════════
router.post("/users", requireAuth, async (req: Request, res: Response) => {
  try {
    const requester = (req as any).user;

    // ✅ Only admin/owner can create users
    if (!requester || (requester.role !== "admin" && requester.role !== "owner")) {
      res.status(403).json({ error: "Admin access required" });
      return;
    }

    const { username, password, role } = req.body;

    if (!username || !password) {
      res.status(400).json({ error: "Username and password are required" });
      return;
    }

    const cleanUsername = String(username).trim();
    if (cleanUsername.length < 3 || cleanUsername.length > 32) {
      res.status(400).json({ error: "Username must be 3-32 characters" });
      return;
    }

    if (password.length < 6) {
      res.status(400).json({ error: "Password must be at least 6 characters" });
      return;
    }

    const users = (await readJSON("users.json")) || [];

    // Check duplicate
    const exists = users.find(
      (u: any) =>
        u.username && u.username.toLowerCase() === cleanUsername.toLowerCase()
    );
    if (exists) {
      res.status(409).json({ error: "Username already taken" });
      return;
    }

    // Validate role
    const validRoles = ["user", "admin", "owner"];
    const finalRole = validRoles.includes(role) ? role : "user";

    // Only owner can create owner
    if (finalRole === "owner" && requester.role !== "owner") {
      res.status(403).json({ error: "Only owner can create another owner" });
      return;
    }

    const bcrypt = await import("bcryptjs");
    const hashedPassword = await bcrypt.default.hash(password, 10);

    const newUser = {
      id: "user-" + Date.now() + "-" + Math.random().toString(36).substring(2, 7),
      username: cleanUsername,
      password: hashedPassword,
      role: finalRole,
      passwordVersion: 0,
      createdAt: new Date().toISOString(),
      lastLogin: null,
    };

    users.push(newUser);
    await writeJSON("users.json", users);

    res.status(201).json({
      message: "User created successfully",
      user: {
        id: newUser.id,
        username: newUser.username,
        role: newUser.role,
      },
    });
  } catch (err: any) {
    console.error("POST user error:", err);
    res.status(500).json({ error: "Failed to create user" });
  }
});

// ═══════════════════════════════════════════
// PUT /api/system/users/:id/role — Change role
// ═══════════════════════════════════════════
router.put("/users/:id/role", requireAuth, async (req: Request, res: Response) => {
  try {
    const requester = (req as any).user;
    if (!requester || (requester.role !== "admin" && requester.role !== "owner")) {
      res.status(403).json({ error: "Admin access required" });
      return;
    }

    const { id } = req.params;
    const { newRole } = req.body;

    if (!["user", "admin", "owner"].includes(newRole)) {
      res.status(400).json({ error: "Invalid role" });
      return;
    }

    const users = (await readJSON("users.json")) || [];
    const idx = users.findIndex((u: any) => u.id === id);

    if (idx === -1) {
      res.status(404).json({ error: "User not found" });
      return;
    }

    if (users[idx].role === "owner" && requester.role !== "owner") {
      res.status(403).json({ error: "Cannot modify owner" });
      return;
    }

    if (newRole === "owner" && requester.role !== "owner") {
      res.status(403).json({ error: "Only owner can promote to owner" });
      return;
    }

    users[idx].role = newRole;
    await writeJSON("users.json", users);

    res.json({ success: true, role: newRole });
  } catch (err) {
    console.error("PUT role error:", err);
    res.status(500).json({ error: "Failed to change role" });
  }
});

// ═══════════════════════════════════════════
// PUT /api/system/users/:id/password — Change password
// ═══════════════════════════════════════════
router.put("/users/:id/password", requireAuth, async (req: Request, res: Response) => {
  try {
    const requester = (req as any).user;
    if (!requester || (requester.role !== "admin" && requester.role !== "owner")) {
      res.status(403).json({ error: "Admin access required" });
      return;
    }

    const { id } = req.params;
    const { newPassword } = req.body;

    if (!newPassword || newPassword.length < 8) {
      res.status(400).json({ error: "Password must be at least 8 characters" });
      return;
    }

    const users = (await readJSON("users.json")) || [];
    const idx = users.findIndex((u: any) => u.id === id);

    if (idx === -1) {
      res.status(404).json({ error: "User not found" });
      return;
    }

    if (users[idx].role === "owner" && requester.role !== "owner") {
      res.status(403).json({ error: "Cannot modify owner" });
      return;
    }

    const bcrypt = await import("bcryptjs");
    users[idx].password = await bcrypt.default.hash(newPassword, 10);
    users[idx].passwordVersion = (users[idx].passwordVersion || 0) + 1;
    await writeJSON("users.json", users);

    res.json({ success: true });
  } catch (err) {
    console.error("PUT password error:", err);
    res.status(500).json({ error: "Failed to change password" });
  }
});

// ═══════════════════════════════════════════
// DELETE /api/system/users/:id — Delete user
// ═══════════════════════════════════════════
router.delete("/users/:id", requireAuth, async (req: Request, res: Response) => {
  try {
    const requester = (req as any).user;
    if (!requester || (requester.role !== "admin" && requester.role !== "owner")) {
      res.status(403).json({ error: "Admin access required" });
      return;
    }

    const { id } = req.params;

    // Cannot delete self
    if (id === requester.id) {
      res.status(400).json({ error: "Cannot delete your own account" });
      return;
    }

    const users = (await readJSON("users.json")) || [];
    const target = users.find((u: any) => u.id === id);

    if (!target) {
      res.status(404).json({ error: "User not found" });
      return;
    }

    if (target.role === "owner" && requester.role !== "owner") {
      res.status(403).json({ error: "Cannot delete owner" });
      return;
    }

    const filtered = users.filter((u: any) => u.id !== id);
    await writeJSON("users.json", filtered);

    res.json({ success: true });
  } catch (err) {
    console.error("DELETE user error:", err);
    res.status(500).json({ error: "Failed to delete user" });
  }
});

// ═══════════════════════════════════════════
// POST /api/system/update — System update
// ═══════════════════════════════════════════
router.post("/update", requireAuth, async (req: Request, res: Response) => {
  try {
    const requester = (req as any).user;
    if (!requester || requester.role !== "owner") {
      res.status(403).json({ error: "Owner access required" });
      return;
    }

    res.json({ success: true, message: "Update triggered" });
  } catch (err) {
    console.error("Update error:", err);
    res.status(500).json({ error: "Failed to trigger update" });
  }
});

export default router;