import React from 'react';
import { Terminal, Hexagon } from 'lucide-react';

// ============================================
// AstroWax Panel V1.80 — Page Header
// Purple Theme + AstroWax Branding
// ============================================

interface PageHeaderProps {
    title: string;
    subtitle?: string;
    actions?: React.ReactNode;
}

export default function PageHeader({ title, subtitle, actions }: PageHeaderProps) {
    return (
        <header className="max-w-7xl mx-auto px-5 md:px-8 pt-16 md:pt-20 pb-16">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-8">
                <div className="reveal active">
                    {/* Breadcrumb line */}
                    <p 
                        className="font-mono text-[11px] md:text-xs tracking-[0.25em] flex items-center gap-2 mb-6 uppercase"
                        style={{ color: 'rgba(168,85,247,.75)' }}
                    >
                        <Hexagon className="w-3.5 h-3.5" 
                            style={{ 
                                filter: 'drop-shadow(0 0 6px rgba(168,85,247,.6))' 
                            }} 
                        />
                        <span style={{ color: 'rgba(168,85,247,.6)' }}>//</span>
                        <span style={{ color: '#c084fc' }}>ASTROWAX.CORE</span>
                        <span style={{ color: 'rgba(168,85,247,.6)' }}>—</span>
                        <span>{subtitle || title}</span>
                    </p>
                    
                    {/* Title with subtle glow */}
                    <h1 
                        className="font-display font-bold leading-[0.85] tracking-tight text-5xl md:text-7xl uppercase text-white"
                        style={{
                            textShadow: '0 0 40px rgba(168,85,247,.15)',
                        }}
                    >
                        {title}
                    </h1>
                    
                    {/* Decorative underline */}
                    <div 
                        className="mt-6 h-px w-24"
                        style={{
                            background: 'linear-gradient(90deg, #a855f7, rgba(168,85,247,.3), transparent)',
                            boxShadow: '0 0 12px rgba(168,85,247,.5)',
                        }}
                    />
                </div>
                
                {actions && (
                    <div 
                        className="flex items-center gap-3 reveal active" 
                        style={{ transitionDelay: '100ms' }}
                    >
                        {actions}
                    </div>
                )}
            </div>
        </header>
    );
}